#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
IMAGE="${IMAGE:-sharelatex/sharelatex:latest}"
UID_NUM="$(id -u)"
GID_NUM="$(id -g)"

DEFAULT_TEXLIVE_REPOS=(
  "https://pi.kwarc.info/historic/systems/texlive/2025/tlnet-final"
  "https://ftp.math.utah.edu/pub/tex/historic/systems/texlive/2025/tlnet-final"
  "https://texlive.texjp.org/2025/tlnet"
  "https://tex.org.uk/systems/texlive/tlnet"
)

if [[ -n "${TEXLIVE_REPO:-}" ]]; then
  TEXLIVE_REPOS=("${TEXLIVE_REPO}")
else
  TEXLIVE_REPOS=("${DEFAULT_TEXLIVE_REPOS[@]}")
fi

CONTAINER_SCRIPT='set -euo pipefail
repo_ok=""
for repo in "$@"; do
  echo "Trying TeX Live repo: ${repo}" >&2
  if tlmgr option repository "${repo}" >/tmp/tlmgr_repo.log 2>&1 && \
     tlmgr install pgf pgfplots booktabs algorithms algorithmicx float >/tmp/tlmgr_structrisk.log 2>&1; then
    repo_ok="${repo}"
    break
  fi
done
if [[ -z "${repo_ok}" ]]; then
  echo "Failed to install TeX packages from all candidate repos." >&2
  cat /tmp/tlmgr_repo.log /tmp/tlmgr_structrisk.log 2>/dev/null || true
  exit 1
fi
echo "Using TeX Live repo: ${repo_ok}" >&2
latexmk -pdf -interaction=nonstopmode -halt-on-error structrisk_acsac2026.tex
chown '${UID_NUM}:${GID_NUM}' structrisk_acsac2026.* figures/* 2>/dev/null || true'

docker run --rm \
  --entrypoint bash \
  -v "${ROOT_DIR}:/work" \
  -w /work \
  "${IMAGE}" \
  -lc "${CONTAINER_SCRIPT}" -- "${TEXLIVE_REPOS[@]}"

#!/usr/bin/env python3
import argparse
import hashlib
import json
import shutil
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parents[1]
MANIFEST = SCRIPT_DIR / 'INCLUDED_PATHS.txt'
SKIP_NAMES = {'__pycache__', '.DS_Store'}
TEXT_EXTENSIONS = {
    '.json',
    '.jsonl',
    '.md',
    '.txt',
    '.tex',
    '.csv',
    '.py',
    '.sh',
    '.yml',
    '.yaml',
}
LEGACY_SIGNAL_KEYS = {'patch_hint', 'control'}


def sanitize_json_value(value):
    if isinstance(value, dict):
        sanitized = {}
        for key, child in value.items():
            if key == 'signals' and isinstance(child, dict):
                sanitized[key] = {
                    signal_key: sanitize_json_value(signal_value)
                    for signal_key, signal_value in child.items()
                    if signal_key not in LEGACY_SIGNAL_KEYS
                }
            else:
                sanitized[key] = sanitize_json_value(child)
        return sanitized
    if isinstance(value, list):
        return [sanitize_json_value(item) for item in value]
    return value


def sanitize_json_text(text: str, suffix: str):
    if suffix == '.jsonl':
        lines = []
        changed = False
        for line in text.splitlines():
            if not line.strip():
                lines.append(line)
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                lines.append(line)
                continue
            sanitized = sanitize_json_value(payload)
            changed = changed or sanitized != payload
            lines.append(json.dumps(sanitized, ensure_ascii=False))
        trailing = '\n' if text.endswith('\n') else ''
        return '\n'.join(lines) + trailing if changed else text
    if suffix == '.json':
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return text
        sanitized = sanitize_json_value(payload)
        if sanitized == payload:
            return text
        return json.dumps(sanitized, indent=2, ensure_ascii=False) + '\n'
    return text


def iter_manifest_entries(path: Path):
    for raw_line in path.read_text(encoding='utf-8').splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue
        yield line


def expand_entry(entry: str):
    matches = sorted(ROOT.glob(entry))
    if matches:
        return matches
    path = ROOT / entry
    return [path] if path.exists() else []


def should_skip(path: Path):
    return any(part in SKIP_NAMES for part in path.parts)


def sanitize_text(text: str):
    return text.replace(str(ROOT.resolve()), '<REPO_ROOT>')


def copy_file(source: Path, destination: Path):
    if source.suffix.lower() in TEXT_EXTENSIONS:
        try:
            content = source.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            shutil.copy2(source, destination)
            return
        content = sanitize_json_text(content, source.suffix.lower())
        destination.write_text(sanitize_text(content), encoding='utf-8')
        return
    shutil.copy2(source, destination)


def copy_path(source: Path, output_root: Path):
    copied = []
    if should_skip(source):
        return copied
    if source.is_dir():
        for child in sorted(source.rglob('*')):
            if child.is_dir() or should_skip(child):
                continue
            copied.extend(copy_path(child, output_root))
        return copied

    relative = source.relative_to(ROOT)
    destination = output_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    copy_file(source, destination)
    copied.append(relative)
    return copied


def sha256sum(path: Path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(65536), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_tree(output_root: Path, copied_files):
    lines = [str(relative) for relative in sorted(copied_files)]
    (output_root / 'TREE.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_checksums(output_root: Path, copied_files):
    lines = []
    for relative in sorted(copied_files):
        digest = sha256sum(output_root / relative)
        lines.append(f'{digest}  {relative}')
    (output_root / 'SHA256SUMS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description='Stage the anonymous StructRisk ACSAC artifact package')
    parser.add_argument('--output', default=str(ROOT / 'StructRisk' / 'outputs' / 'acsac2026_anonymous_artifact'))
    parser.add_argument('--clean', action='store_true', help='remove the output directory before copying')
    args = parser.parse_args()

    output_root = Path(args.output).resolve()
    if args.clean and output_root.exists():
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    copied_files = []
    missing_entries = []
    for entry in iter_manifest_entries(MANIFEST):
        matches = expand_entry(entry)
        if not matches:
            missing_entries.append(entry)
            continue
        for match in matches:
            copied_files.extend(copy_path(match, output_root))

    copied_files = sorted(set(copied_files))
    write_tree(output_root, copied_files)
    write_checksums(output_root, copied_files)

    metadata = {
        'manifest': str(MANIFEST.relative_to(ROOT)),
        'copied_file_count': len(copied_files),
        'missing_entries': missing_entries,
        'output_root_name': output_root.name,
    }
    (output_root / 'PACKAGE_METADATA.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()

# Anonymous Artifact Package for `StructRisk` (ACSAC 2026 Submission)

This directory provides a reviewer-facing, anonymous artifact package plan for the current `StructRisk` paper.

## Scope

The package is designed to support three reproducibility goals without requiring network access or live LLM/API calls:

- Rebuild the paper's main evaluation tables from prepared ranked outputs.
- Re-run the offline ranking pipeline from the prepared main-evaluation artifact index and shipped responses.
- Audit the anonymized LLM prompts/responses and the replay-based CASR comparator reports.
- Re-run the MAGMA crash-backed validation from shipped finding-level MAGMA slices and cached CVSS records.

The full repository additionally contains broader MAGMA reconstruction utilities, but the anonymous reviewer package is centered on the shipped unified crash-backed MAGMA slice over 49 deduplicated findings across nine projects. The shipped MAGMA inventory audit covers 138 bug records and 125 distinct CVEs, with 84 HIGH-or-CRITICAL CVEs under the preferred NVD CVSS, plus a project-level inventory-versus-slice coverage table for the unified crash-backed slice.

The anonymous package is centered on processed main-evaluation artifacts rather than on re-fuzzing third-party projects from scratch.

## What Is Included

- `StructRisk/scripts/`: all ranking, baseline, significance, and helper scripts used in the paper.
- `StructRisk/generated/phase1_artifact_index.jsonl`: processed main-evaluation artifact index. The `phase1_*` prefix is an internal historical name.
- `StructRisk/generated/phase1_offline_*.jsonl|json|md`: ranked outputs, metrics, and summaries for the reported baselines.
- `StructRisk/generated/phase1_within_project_metrics.*`: within-project evaluation outputs.
- `StructRisk/generated/phase1_within_evalonly_metrics.*` and `StructRisk/generated/phase1_within_evalonly_significance.*`: held-out Eval-only within-project sanity-check outputs over the five positive multi-finding evaluation projects.
- `StructRisk/generated/phase1_offline_significance.*`: bootstrap/permutation significance outputs.
- `StructRisk/generated/phase1_ablation.*`: feature ablation outputs.
- `StructRisk/generated/phase1_llm_card_*.jsonl`, `StructRisk/generated/phase1_offline_llm_lcr_*`, and `StructRisk/generated/phase1_within10_llm_lcr_*`: anonymized LLM-card prompts/responses plus deterministic local tie-resolution audit outputs.
- `StructRisk/generated/phase1_casr_reports/`: CASR reports, stderr logs, and timeout records for the replay-based comparator.
- `StructRisk/user75_cve_summary.csv` and `StructRisk/user75_cve_tables.md`: anonymized CVE provenance tables covering CVE IDs, projects, CVSS/CNA/NVD status, and disclosure status.
- `StructRisk/generated/high_risk_disclosure_alignment.*` and `StructRisk/generated/high_risk_disclosures_summary.md`: alignment summaries for the disclosure-backed HIGH cases; direct public issue/advisory URLs are redacted in the double-blind package and can be restored for the non-anonymous release.
- `StructRisk/external/magma/` and `StructRisk/generated/magma*_*.{json,jsonl,csv,md}`: the MAGMA inventory audit inputs plus crash-backed MAGMA findings, ranked outputs, summaries, and project-level coverage tables.
- Paper figures are embedded directly in `structrisk_acsac2026.tex` to avoid external figure-source mismatches during upload.
- `structrisk_acsac2026.tex`: anonymous paper source for cross-referencing claims. The compiled PDF is intentionally not staged here; rebuild it with the helper below after final text changes.

The concrete staging list is maintained in `StructRisk/artifact_acsac2026/INCLUDED_PATHS.txt`. For a claim-by-claim map from paper tables to output files, see `StructRisk/artifact_acsac2026/CANONICAL_OUTPUTS.md`.

## What Is Not Included

- The full third-party source mirror under `StructRisk/StructRisk_src_full/`.
- Raw fuzzing campaigns and original third-party corpora.
- The larger MAGMA rebuild-and-replay environments and the 1.9GB public PoC archives.
- Any live API keys, model credentials, or author-identifying metadata.

This omission is intentional for compactness, licensing hygiene, and anonymous review. The shipped processed benchmark, ranked outputs, prompts/responses, CASR reports, and MAGMA evidence-card slices are sufficient to audit the reported results.

## Requirements

Core reproduction uses only the Python standard library.

- `Python >= 3.10`
- `bash`

Optional dependencies:

- Docker is only relevant if you attempt to re-run replay-based CASR or MAGMA rebuild steps from original environments; it is not required for the shipped anonymous package quick check.

## Quick Start

From the repository root:

```bash
bash StructRisk/artifact_acsac2026/run_quick_check.sh
```

This quick path:

- regenerates the within-project summary,
- regenerates the ablation summary,
- rebuilds LLM-CardScore from shipped anonymized responses and then deterministically derives LLM-LCR with source-site novelty for tied card scores,
- checks that CASR reports are present,
- rebuilds the unified crash-backed MAGMA validation summary from shipped findings,
- verifies that the shipped significance outputs are present.

`run_quick_check.sh` defaults to a reviewer-friendly smoke test and therefore does **not** recompute the full significance table.

The shipped LLM-CardScore responses were generated with a fixed `gpt-5.4` configuration using the `xhigh` reasoning setting. The anonymous artifact supports deterministic replay from these cached responses rather than live regeneration against a future closed-model version.

To force a significance rerun from the shipped ranked outputs, use:

```bash
RUN_SIGNIFICANCE=1 BOOTSTRAP_ROUNDS=20000 bash StructRisk/artifact_acsac2026/run_quick_check.sh
```

For the complete end-to-end offline rerun, use `run_full_offline.sh`.

## Optional Paper Compilation

The paper PDF can be rebuilt with the local Overleaf/ShareLaTeX image used during validation:

```bash
bash StructRisk/artifact_acsac2026/compile_paper_overleaf_env.sh
```

The helper uses `sharelatex/sharelatex:latest`, points `tlmgr` at the TeX Live 2025 frozen repository, installs the small set of packages needed by the paper figures (`pgf`, `pgfplots`, and `booktabs`), and then runs `latexmk` on `structrisk_acsac2026.tex`.

## Full Offline Reproduction

To rerun the non-network pipeline from the shipped canonical main-evaluation split:

```bash
BOOTSTRAP_ROUNDS=20000 bash StructRisk/artifact_acsac2026/run_full_offline.sh
```

This script performs the following steps:

1. Verifies the shipped canonical main-evaluation split by default; set `REBUILD_PHASE1_SPLIT=1` only if you want to regenerate exploratory split files from `phase1_artifact_index.jsonl`.
2. Re-runs the public, artifact, support-count, crash-state, report-kNN, CASR, and StructRisk baselines.
3. Re-runs the LLM baselines from shipped anonymized responses and the cached LCR base ranking.
4. Recomputes ablations, within-project evaluation, and the crash-backed MAGMA validation outputs; shipped significance outputs are reused unless `RUN_SIGNIFICANCE=1` is set.

The CASR replay baseline is skipped by default because the anonymous package does not bundle the full third-party source mirror. To force a CASR rerun in a local environment that has the required source tree and replay dependencies, set:

```bash
RUN_CASR=1 bash StructRisk/artifact_acsac2026/run_full_offline.sh
```

## Main Claims Covered

The package is intended to support reviewer verification of the following paper claims:

- Global ranking results in the primary held-out evaluation table.
- Within-project ranking results and the associated macro metrics.
- Bootstrap/permutation significance summary.
- Fixed-scorer ablation study.
- Leakage-controlled LLM evaluation using anonymous prompts, manifests, and shipped responses.
- Replay-based CASR comparator auditability through ranked outputs and released CASR reports.
- MAGMA crash-backed validation and full-inventory MAGMA severity audit.

## Key Output Files

After running the scripts above, the main files to inspect are:

- `StructRisk/generated/phase1_offline_significance.md`
- `StructRisk/generated/phase1_within_project_metrics.md`
- `StructRisk/generated/phase1_ablation.md` (structured-core ablation)
- `StructRisk/generated/phase1_offline_manual_metrics.json`
- `StructRisk/generated/phase1_offline_llm_card_metrics.json`
- `StructRisk/generated/phase1_offline_llm_lcr_metrics.json`
- `StructRisk/generated/phase1_offline_casr_summary.md`
- `StructRisk/generated/magma_unified_crash_backed_external_summary.md`
- `StructRisk/generated/magma_unified_crash_backed_external_casr_summary.md`
- `StructRisk/generated/magma_inventory_audit.md`
- `StructRisk/generated/magma_inventory_project_coverage.csv`

## Anonymous Packaging

To stage a clean reviewer-facing package into a separate directory:

```bash
python3 StructRisk/artifact_acsac2026/stage_anonymous_artifact.py \
  --output /tmp/structrisk_acsac2026_artifact
```

The staging script copies the paths listed in `INCLUDED_PATHS.txt`, preserves relative paths, and generates:

- `SHA256SUMS.txt`
- `TREE.txt`
- `PACKAGE_METADATA.json`

Before submission, review `StructRisk/artifact_acsac2026/ANONYMITY_CHECKLIST.md`.

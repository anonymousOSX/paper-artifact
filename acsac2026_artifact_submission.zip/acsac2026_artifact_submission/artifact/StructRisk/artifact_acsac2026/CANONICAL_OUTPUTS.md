# Canonical Outputs for Paper Verification

This document lists the generated files that correspond to the paper's reported tables and figures. Paths are relative to the artifact root.

## Phase-1 Global Evaluation

- `StructRisk/generated/phase1_offline_balanced_findings.jsonl`: released 120-finding capped main-evaluation set used to derive the dev/eval splits.
- `StructRisk/generated/phase1_offline_full_findings.jsonl`: compatibility copy of the same released capped set; the submitted paper reports the capped evaluation set rather than an uncapped pre-release reconstruction.
- `StructRisk/generated/phase1_offline_eval.jsonl`: 78-finding held-out evaluation split.
- `StructRisk/generated/phase1_offline_public_severity_metrics.json`: Public-Severity hindsight metadata baseline.
- `StructRisk/generated/phase1_offline_support_count_metrics.json`: Support-Count frequency-only baseline.
- `StructRisk/generated/phase1_offline_artifact_metrics.json`: Artifact-Completeness baseline.
- `StructRisk/generated/phase1_offline_asan_metrics.json`: ASan-Severity baseline.
- `StructRisk/generated/phase1_offline_crashstate_metrics.json`: Crash-State baseline.
- `StructRisk/generated/phase1_offline_reportknn_metrics.json`: StackDedup finding-level comparator.
- `StructRisk/generated/phase1_offline_casr_metrics.json`: CASR-Severity comparator.
- `StructRisk/generated/phase1_offline_llm_card_metrics.json`: direct LLM-CardScore baseline metrics.
- `StructRisk/generated/phase1_offline_manual_metrics.json`: StructRisk fixed-score metrics.
- `StructRisk/generated/phase1_offline_manual_weights.json`: fixed StructRisk prior used by the paper.
- `StructRisk/generated/phase1_offline_llm_lcr_metrics.json`: global-order sanity check for StructRisk+LLM-LCR; it matches the StructRisk global order by construction.
- `StructRisk/generated/phase1_offline_significance.json` and `.md`: global bootstrap/permutation significance summary.

## Within-Project Evaluation

- `StructRisk/generated/phase1_within10_eval.jsonl`: ten positive multi-finding projects used for the main within-project view.
- `StructRisk/generated/phase1_within_project_metrics.json`, `.csv`, and `.md`: main within-project table, including StructRisk+LLM-LCR macro metrics.
- `StructRisk/generated/phase1_within_project_significance.json` and `.md`: within-project significance against Public-Severity.
- `StructRisk/generated/phase1_within_evalonly_metrics.json`, `.csv`, and `.md`: Eval-only within-project sanity check.
- `StructRisk/generated/phase1_within_evalonly_significance.json` and `.md`: Eval-only within-project significance check.

## Ablation and LLM Audit Trail

- `StructRisk/generated/phase1_ablation.json` and `.md`: ablation table for StructRisk.
- `StructRisk/generated/phase1_weight_sensitivity.json` and `.md`: 77-variant ±20% fixed-weight perturbation envelope. This is a robustness audit against single-vector post-hoc tuning concerns; it is not used to select a replacement scorer.
- `StructRisk/generated/phase1_llm_card_prompts*.jsonl`: anonymized LLM-CardScore prompts.
- `StructRisk/generated/phase1_llm_card_responses*.jsonl` and `.txt`: cached LLM-CardScore responses.
- `StructRisk/generated/phase1_offline_llm_lcr_summary.md`: global-order sanity-check audit for StructRisk+LLM-LCR.
- `StructRisk/generated/phase1_within10_llm_lcr_summary.md`: deterministic StructRisk+LLM-LCR local tie-resolution replay summary.

The submitted paper uses LLM-LCR only as deterministic same-project evidence-profile tie resolution. The LLM-card scores were generated with a fixed `gpt-5.4` configuration using the `xhigh` reasoning setting. The main within-project results come from `phase1_within_project_metrics.*`; the `phase1_within10_llm_lcr_*` files are audit trails for the local reordering decisions. There is no additive residual weight or tuned ambiguity threshold; the artifact supports deterministic replay from shipped LLM-card scores rather than model-independent regeneration against future closed-model versions.

## MAGMA Crash-Backed Validation

- `StructRisk/generated/magma_inventory_audit.json` and `.md`: full MAGMA inventory audit over 138 bug records and 125 distinct CVEs.
- `StructRisk/generated/magma_inventory_project_coverage.csv`: project-level inventory-versus-slice coverage.
- `StructRisk/generated/magma_unified_crash_backed_findings.jsonl`: unified 49-finding crash-backed evidence-card slice used in the main MAGMA table.
- `StructRisk/generated/magma_unified_crash_backed_external_metrics.json`: MAGMA validation metrics plus auxiliary diagnostics.
- `StructRisk/generated/magma_unified_crash_backed_external_summary.md`: human-readable MAGMA validation summary.
- `StructRisk/generated/magma_unified_crash_backed_external_*_ranked.jsonl`: per-method ranked outputs for the main MAGMA table and auxiliary diagnostics.
- `StructRisk/generated/magma_unified_crash_backed_casr_reports/`: CASR reports and timeout/error logs for the MAGMA CASR comparator.

The `magma_local_*` and `magma_poc49_*` files are component replay audits used to construct and document the unified MAGMA slice. They are not separate main-text benchmarks.

## Provenance and Label Audit

- `StructRisk/user75_cve_summary.csv`: anonymized CVE provenance table.
- `StructRisk/user75_cve_tables.md`: human-readable CVE archive summary.
- `StructRisk/generated/high_risk_disclosure_alignment.*`: alignment between disclosure-backed HIGH CVEs and main-evaluation findings.
- `StructRisk/generated/high_risk_disclosures_summary.md`: HIGH-case disclosure summary with direct issue/advisory URLs redacted for double-blind review.

## Files to Ignore for Paper Verification

Files whose names begin with `tmp_`, `magma_tmp_`, or `phase1_exactreport_` are exploratory development outputs if present in a working tree. They are not used for the submitted paper's reported tables.

#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

BOOTSTRAP_ROUNDS="${BOOTSTRAP_ROUNDS:-20000}"
SEED="${SEED:-1337}"
RUN_SIGNIFICANCE="${RUN_SIGNIFICANCE:-0}"

echo "[1/6] Rebuilding StructRisk ablation summary"
python3 StructRisk/scripts/phase1_ablation.py \
  --eval StructRisk/generated/phase1_offline_eval.jsonl \
  --weights StructRisk/generated/phase1_offline_manual_weights.json \
  --json-out StructRisk/generated/phase1_ablation.json \
  --md-out StructRisk/generated/phase1_ablation.md
test -f StructRisk/generated/phase1_weight_sensitivity.json
test -f StructRisk/generated/phase1_weight_sensitivity.md
echo "Using shipped weight-sensitivity envelope (run StructRisk/scripts/phase1_weight_sensitivity.py to recompute)."

echo "[2/6] Rebuilding shipped LLM outputs without network access"
python3 StructRisk/scripts/phase1_llm_card_baseline.py \
  --mode responses \
  --eval StructRisk/generated/phase1_offline_eval.jsonl \
  --responses StructRisk/generated/phase1_llm_card_responses_clean.jsonl \
  --ranked-out StructRisk/generated/phase1_offline_llm_card_ranked.jsonl \
  --metrics-out StructRisk/generated/phase1_offline_llm_card_metrics.json \
  --summary-out StructRisk/generated/phase1_offline_llm_card_summary.md

python3 StructRisk/scripts/phase1_local_tie_resolution.py \
  --base StructRisk/generated/phase1_offline_manual_ranked.jsonl \
  --llm-card StructRisk/generated/phase1_offline_llm_card_ranked.jsonl \
  --output StructRisk/generated/phase1_offline_llm_lcr_ranked.jsonl \
  --metrics-out StructRisk/generated/phase1_offline_llm_lcr_metrics.json \
  --summary-out StructRisk/generated/phase1_offline_llm_lcr_summary.md

python3 StructRisk/scripts/phase1_local_tie_resolution.py \
  --base StructRisk/generated/phase1_within10_manual_ranked.jsonl \
  --llm-card StructRisk/generated/phase1_within10_llm_card_ranked.jsonl \
  --output StructRisk/generated/phase1_within10_llm_lcr_ranked.jsonl \
  --metrics-out StructRisk/generated/phase1_within10_llm_lcr_metrics.json \
  --summary-out StructRisk/generated/phase1_within10_llm_lcr_summary.md

echo "[3/6] Rebuilding within-project metrics from current ranked outputs"
python3 StructRisk/scripts/phase1_within_project_eval.py
python3 StructRisk/scripts/phase1_within_project_eval.py \
  --project binaryen \
  --project openbabel \
  --project squirrel \
  --project wabt \
  --project xlnt \
  --json-out StructRisk/generated/phase1_within_evalonly_metrics.json \
  --csv-out StructRisk/generated/phase1_within_evalonly_metrics.csv \
  --md-out StructRisk/generated/phase1_within_evalonly_metrics.md

echo "[4/6] Significance summary"
if [[ "$RUN_SIGNIFICANCE" == "1" ]]; then
  python3 StructRisk/scripts/phase1_significance.py --bootstrap-rounds "$BOOTSTRAP_ROUNDS" --seed "$SEED"
  python3 StructRisk/scripts/phase1_within_project_significance.py --bootstrap-rounds "$BOOTSTRAP_ROUNDS" --seed "$SEED"
  python3 StructRisk/scripts/phase1_within_project_significance.py \
    --project binaryen \
    --project openbabel \
    --project squirrel \
    --project wabt \
    --project xlnt \
    --bootstrap-rounds "$BOOTSTRAP_ROUNDS" \
    --seed "$SEED" \
    --json-out StructRisk/generated/phase1_within_evalonly_significance.json \
    --md-out StructRisk/generated/phase1_within_evalonly_significance.md
else
  test -f StructRisk/generated/phase1_offline_significance.md
  test -f StructRisk/generated/phase1_offline_significance.json
  test -f StructRisk/generated/phase1_within_project_significance.md
  test -f StructRisk/generated/phase1_within_project_significance.json
  test -f StructRisk/generated/phase1_within_evalonly_significance.md
  test -f StructRisk/generated/phase1_within_evalonly_significance.json
  echo "Using shipped significance outputs (set RUN_SIGNIFICANCE=1 to recompute)."
fi

echo "[5/6] Rebuilding MAGMA crash-backed validation"
if [[ -f StructRisk/generated/magma_local_crash_backed_enriched_artifacts.jsonl && \
      -f StructRisk/generated/magma_poc49_crash_backed_enriched_artifacts.jsonl ]]; then
  python3 StructRisk/scripts/magma_unified_crash_backed_slice.py
else
  test -f StructRisk/generated/magma_unified_crash_backed_findings.jsonl
  echo "Using shipped unified MAGMA evidence-card slice (component replay artifacts not bundled)."
fi
python3 StructRisk/scripts/magma_crash_backed_benchmark.py \
  --input StructRisk/generated/magma_unified_crash_backed_findings.jsonl \
  --out-prefix StructRisk/generated/magma_unified_crash_backed_external
python3 StructRisk/scripts/magma_inventory_audit.py

echo "[6/6] Sanity-checking CASR reports"
find StructRisk/generated/phase1_casr_reports -type f 2>/dev/null | wc -l | awk '{print "CASR report/log files:", $1}'

echo "Quick check completed. Inspect:"
echo "  StructRisk/generated/phase1_offline_significance.md"
echo "  StructRisk/generated/phase1_within_project_metrics.md"
echo "  StructRisk/generated/phase1_ablation.md"
echo "  StructRisk/generated/magma_unified_crash_backed_external_summary.md"
echo "  StructRisk/generated/magma_inventory_audit.md"

# Support-Count Baseline Summary

## Primary Metrics
- `HighRisk@5=1`
- `HighRisk@10=3`
- `NDCG@5=0.1461`
- `NDCG@10=0.2305`
- `Rank-to-First-HighRisk=4`
- `Effort-to-First-HighRisk=38.39`

## Top-10 Findings
- `1`. `binaryen::finding::86588299` risk=0 score=682.0 support=`682` report=`project`
- `2`. `binaryen::finding::56457462` risk=0 score=498.0 support=`498` report=`exact`
- `3`. `sokol::finding::31523467` risk=0 score=354.0 support=`354` report=`project`
- `4`. `soloud::finding::46506111` risk=3 score=142.0 support=`142` report=`exact`
- `5`. `soloud::finding::57470285` risk=0 score=112.0 support=`112` report=`exact`
- `6`. `lily::finding::14268676` risk=0 score=100.0 support=`100` report=`exact`
- `7`. `binaryen::finding::79565612` risk=0 score=96.0 support=`96` report=`exact`
- `8`. `wren::finding::49674825` risk=3 score=69.0 support=`69` report=`exact`
- `9`. `wren::finding::13953049` risk=3 score=57.0 support=`57` report=`exact`
- `10`. `raylib::finding::06375443` risk=0 score=37.0 support=`37` report=`exact`

# High-Risk Disclosure Summary

- Records: `23`
- Projects: `14`
- With ASan report text: `23`
- With root-cause discussion: `18`
- With reproduce section: `22`
- With explicit or recovered location: `23`

| Project | CVE | Type | CVSS | Source | ASan | Root Cause | URL |
|---|---|---|---:|---|---:|---:|---|
| berry | CVE-2026-3285 | Out-Of-Bounds | 7.8 | nvd@nist.gov | 1 | 0 | <URL-redacted-for-double-blind-review> |
| binaryen | CVE-2025-14956 | Heap-based Buffer Overflow | 7.1 | nvd@nist.gov | 1 | 0 | <URL-redacted-for-double-blind-review> |
| libfastcommon | CVE-2026-2016 | Stack-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 0 | <URL-redacted-for-double-blind-review> |
| lily | CVE-2026-2660 | Use After Free | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| lily | CVE-2026-2662 | Out-Of-Bounds | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| minisat | CVE-2026-2644 | Out-Of-Bounds | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| openbabel | CVE-2026-2704 | Out-Of-Bounds | 8.1 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| openbabel | CVE-2026-2705 | Out-Of-Bounds | 8.1 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| raylib | CVE-2025-15533 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| raylib | CVE-2025-15534 | Integer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| sokol | CVE-2025-14958 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| sokol | CVE-2025-15155 | Stack-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| soloud | CVE-2026-3393 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 0 | <URL-redacted-for-double-blind-review> |
| soloud | CVE-2026-3394 | Memory Corruption | 7.8 | nvd@nist.gov | 1 | 0 | <URL-redacted-for-double-blind-review> |
| squirrel | CVE-2026-2659 | Out-Of-Bounds | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| squirrel | CVE-2026-2661 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| wabt | CVE-2025-15411 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| wabt | CVE-2025-15412 | Memory Corruption | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| wasm3 | CVE-2025-15413 | Memory Corruption | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| wren | CVE-2026-2858 | Out-Of-Bounds | 7.1 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| wren | CVE-2026-3386 | Out-Of-Bounds | 7.1 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| xlnt | CVE-2026-3463 | Heap-based Buffer Overflow | 7.8 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |
| xlnt | CVE-2026-3663 | Out-Of-Bounds | 7.1 | nvd@nist.gov | 1 | 1 | <URL-redacted-for-double-blind-review> |

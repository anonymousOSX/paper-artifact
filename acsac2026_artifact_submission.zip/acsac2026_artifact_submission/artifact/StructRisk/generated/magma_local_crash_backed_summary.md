# MAGMA Crash-Backed Component Summary

- Raw artifacts: `1070`
- Deduplicated findings: `23`
- Projects: `9`
- HIGH-or-CRITICAL positives: `12`
- Projects with reports: `9`

## Project Summary

- `libpng`: findings=4, positives=1, avg_support=193.25, avg_site_anchor=0.5, avg_locality=0.85
- `libsndfile`: findings=1, positives=0, avg_support=1.0, avg_site_anchor=0.5, avg_locality=0.85
- `libtiff`: findings=4, positives=2, avg_support=2.5, avg_site_anchor=0.5, avg_locality=0.85
- `libxml2`: findings=1, positives=1, avg_support=16.0, avg_site_anchor=0.5, avg_locality=0.85
- `lua`: findings=1, positives=0, avg_support=1.0, avg_site_anchor=0.5, avg_locality=0.85
- `openssl`: findings=5, positives=4, avg_support=48.4, avg_site_anchor=0.5, avg_locality=0.85
- `php`: findings=1, positives=1, avg_support=1.0, avg_site_anchor=0.5, avg_locality=0.85
- `poppler`: findings=3, positives=0, avg_support=6.0, avg_site_anchor=0.5, avg_locality=0.85
- `sqlite3`: findings=3, positives=3, avg_support=2.67, avg_site_anchor=0.5, avg_locality=0.85

## Example Cards

- `libpng::finding::67434740` (libpng): bugs=AAH003, cves=CVE-2015-8472, asan=DEADLYSIGNAL
- `libpng::finding::62769382` (libpng): bugs=AAH008, cves=CVE-2013-6954, asan=DEADLYSIGNAL
- `libpng::finding::46928917` (libpng): bugs=AAH001, cves=CVE-2018-13785, asan=DEADLYSIGNAL
- `libpng::finding::56002180` (libpng): bugs=AAH007, cves=n/a, asan=DEADLYSIGNAL
- `libsndfile::finding::56933028` (libsndfile): bugs=SND017, cves=n/a, asan=DEADLYSIGNAL

Infrastructure Notes
====================

Required for quick checks:

  - bash
  - Python >= 3.10 using only the Python standard library

Not required for the submitted quick checks:

  - network access
  - live LLM/API credentials
  - Docker
  - LaTeX

Optional: Docker and replay environments are only relevant for reconstructing
selected CASR/MAGMA component replays from original environments. The submitted
artifact instead includes processed evidence-card slices, ranked outputs, CASR
reports/logs, and cached LLM responses so that reviewers can exercise the paper
claims offline.

StructRisk ACSAC 2026 Anonymous Artifact
=======================================

This package follows the ACSAC 2026 paper-artifact layout:

  artifact/        The anonymous StructRisk artifact package and paper source.
  infrastructure/  Environment notes and dependency assumptions.
  claims/          Claim-specific reproduction scripts and expected outputs.
  install.sh       Lightweight environment check; no network access required.
  use.txt          Reviewer workflow and expected running time.
  license.txt      License and third-party-data notes for anonymous review.

The artifact is designed for offline review. It does not require live LLM/API
calls, network access, or Docker for the quick checks. The included scripts use
Python >= 3.10 and bash. Optional full replay/CASR environments are documented
inside artifact/StructRisk/artifact_acsac2026/README.md, but the submitted
package centers on the shipped processed benchmark and cached outputs.

Quick start:

  ./install.sh
  bash claims/claim1_global_queue/run.sh
  bash claims/claim2_within_project/run.sh
  bash claims/claim3_ablation_sensitivity/run.sh
  bash claims/claim4_magma_validation/run.sh

For a complete claim-to-output map, see:

  artifact/StructRisk/artifact_acsac2026/CANONICAL_OUTPUTS.md

For anonymity notes, see:

  artifact/StructRisk/artifact_acsac2026/ANONYMITY_CHECKLIST.md

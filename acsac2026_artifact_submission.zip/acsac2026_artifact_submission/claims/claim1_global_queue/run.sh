#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/artifact"
python3 - <<'PY'
import json, math
base='StructRisk/generated/'
manual=json.load(open(base+'phase1_offline_manual_metrics.json'))
asan=json.load(open(base+'phase1_offline_asan_metrics.json'))
sig=json.load(open(base+'phase1_offline_significance.json'))
def close(a,b,t=5e-4):
    if abs(a-b)>t: raise AssertionError((a,b))
assert manual['HighRisk@5']==5
assert manual['HighRisk@10']==8
close(manual['NDCG@5'],1.0)
close(manual['NDCG@10'],0.8522)
assert asan['HighRisk@10']==1
close(asan['NDCG@10'],0.1100)
text=json.dumps(sig)
assert '0.03125369547387896' in text
assert '0.7421246259355073' in text
print('claim1_global_queue: PASS')
PY

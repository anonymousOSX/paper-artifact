#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/artifact"
python3 - <<'PY'
import json
base='StructRisk/generated/'
ab={r['name']:r for r in json.load(open(base+'phase1_ablation.json'))}
def close(a,b,t=5e-4):
    if abs(a-b)>t: raise AssertionError((a,b))
assert ab['Full']['global']['HighRisk@10']==8
close(ab['Full']['global']['NDCG@10'],0.8522)
assert ab['-weak']['global']['HighRisk@10']==5
close(ab['-weak']['global']['NDCG@10'],0.5965)
ws=json.load(open(base+'phase1_weight_sensitivity.json'))['envelopes']
close(ws['within_project']['NDCG@5']['min'],0.8534)
close(ws['within_project']['NDCG@5']['max'],0.8622)
close(ws['within_project']['MAP']['min'],0.8075)
close(ws['within_project']['MAP']['max'],0.8250)
close(ws['within_lcr_project']['NDCG@5']['min'],0.8717)
close(ws['within_lcr_project']['NDCG@5']['max'],0.9023)
close(ws['within_lcr_project']['MAP']['min'],0.8333)
close(ws['within_lcr_project']['MAP']['max'],0.8750)
print('claim3_ablation_sensitivity: PASS')
PY

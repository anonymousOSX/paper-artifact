#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/artifact"
python3 - <<'PY'
import json
base='StructRisk/generated/'
m=json.load(open(base+'magma_unified_crash_backed_external_metrics.json'))
inv=json.load(open(base+'magma_inventory_audit.json'))
def close(a,b,t=5e-4):
    if abs(a-b)>t: raise AssertionError((a,b))
assert m['findings']==49
assert m['projects']==9
assert m['high_or_critical_positives']==31
assert m['global']['StructRisk']['HighRisk@10']==8
close(m['global']['StructRisk']['NDCG@10'],0.8923)
full=inv['full_inventory']
assert full['bug_records']==138
assert full['distinct_cves']==125
assert full['high_or_critical_cves']==84
print('claim4_magma_validation: PASS')
PY

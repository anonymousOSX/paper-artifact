#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/artifact"
python3 - <<'PY'
import json
base='StructRisk/generated/'
metrics=json.load(open(base+'phase1_within_project_metrics.json'))['macro']
rows={(r['scope'],r['method']):r for r in metrics}
def close(a,b,t=5e-4):
    if abs(a-b)>t: raise AssertionError((a,b))
pub=rows[('multi-finding-projects','Public-Severity')]
lcr=rows[('multi-finding-projects','StructRisk+LLM-LCR')]
close(pub['NDCG@5'],0.5126); close(pub['MAP'],0.4696)
close(lcr['HR@1'],0.9000); close(lcr['HR@3'],1.7000)
close(lcr['NDCG@5'],0.9023); close(lcr['MRR'],0.9333); close(lcr['MAP'],0.8750)
sig=json.load(open(base+'phase1_within_project_significance.json'))
perm=sig['permutation']['StructRisk+LLM-LCR vs Public-Severity']
close(perm['NDCG@5']['exact_two_sided_p'],0.0049)
close(perm['MAP']['exact_two_sided_p'],0.0068)
print('claim2_within_project: PASS')
PY

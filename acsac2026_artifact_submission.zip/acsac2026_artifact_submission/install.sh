#!/usr/bin/env bash
set -euo pipefail

python3 - <<'PY'
import sys
major, minor = sys.version_info[:2]
if (major, minor) < (3, 10):
    raise SystemExit(f"Python >= 3.10 required, found {major}.{minor}")
print(f"Python OK: {major}.{minor}")
PY

test -d artifact/StructRisk/generated
test -f artifact/StructRisk/artifact_acsac2026/run_quick_check.sh
test -f artifact/StructRisk/artifact_acsac2026/CANONICAL_OUTPUTS.md

echo "StructRisk artifact environment check passed."
echo "No network access, API keys, Docker, or LaTeX are required for quick checks."

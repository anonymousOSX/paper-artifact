StructRisk Anonymous Artifact
=============================

This package follows the required paper-artifact layout:

  artifact/        Main code, processed data, and cached outputs.
  infrastructure/  Environment notes and dependency assumptions.
  claims/          Claim-specific reproduction scripts and expected outputs.
  install.sh       Lightweight environment check; no network access required.
  use.txt          Reviewer workflow and expected running time.
  license.txt      License and third-party-data notes for anonymous review.

The artifact is designed for offline review. It does not require live LLM/API
calls, network access, or Docker for the quick checks. The included scripts use
Python >= 3.10 and bash. The submitted package centers on the shipped processed
benchmark, evidence-card slices, ranked outputs, cached LLM responses, and CASR
logs needed to audit the reported claims.

Quick start:

  ./install.sh
  bash claims/claim1_global_queue/run.sh
  bash claims/claim2_within_project/run.sh
  bash claims/claim3_ablation_sensitivity/run.sh
  bash claims/claim4_magma_validation/run.sh

For the paper-level quick check, run:

  cd artifact
  bash StructRisk/artifact_2026/run_quick_check.sh
